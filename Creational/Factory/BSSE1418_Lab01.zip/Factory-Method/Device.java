public interface Device{
	public abstract void powerOn();
	
	public abstract void powerOff();
	
}
