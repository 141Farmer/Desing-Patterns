public class Smartphone implements Device{
    private String property;

    public void powerOff(){
        System.out.println("Smartphone is off");
    }


    public void powerOn(){
        System.out.println("Smartphone is on");
    }
}
