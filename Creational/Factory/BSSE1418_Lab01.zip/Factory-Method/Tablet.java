public class Tablet implements Device{

    private String property;

    public void powerOff(){
        System.out.println("Tablet is off");
    }


    public void powerOn(){
        System.out.println("Tablet is on");
    }
}
