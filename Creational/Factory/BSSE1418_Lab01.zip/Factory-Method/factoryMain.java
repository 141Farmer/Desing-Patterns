public class factoryMain{
    public static void main(String[] args) {


        Device sphone=new Smartphone();
        sphone.powerOff();

        Device ltop=new Laptop();
        ltop.powerOn();

        Device tlet=new Tablet();
        tlet.powerOff();


    }
}